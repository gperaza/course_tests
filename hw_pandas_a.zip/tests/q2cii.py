OK_FORMAT = True

test = {   'name': 'q2cii',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(missing_zip_address_count) == pd.Series\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(missing_zip_address_count) == 135\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(missing_zip_address_count['3914 Judah St'] == 1)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
