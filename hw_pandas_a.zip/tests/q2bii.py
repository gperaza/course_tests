OK_FORMAT = True

test = {   'name': 'q2bii',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(invalid_zip_bus) == pd.DataFrame\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(invalid_zip_bus) == 230\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
