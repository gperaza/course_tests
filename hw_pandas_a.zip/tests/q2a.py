OK_FORMAT = True

test = {   'name': 'q2a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(zip_counts) == pd.Series\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> zip_counts.shape[0] == 63\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(zip_counts['94103'] == 562)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
