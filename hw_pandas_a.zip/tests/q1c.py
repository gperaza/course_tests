OK_FORMAT = True

test = {   'name': 'q1c',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> q1c.upper() in set(['A', 'B', 'C'])\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
