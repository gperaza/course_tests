OK_FORMAT = True

test = {   'name': 'q3cii',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> type(ins['timestamp'][1]) == pd.Timestamp\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
