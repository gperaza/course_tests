OK_FORMAT = True

test = {   'name': 'TODO',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> bool(top3.shape[0] == 3)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(type(top3) == type(pd.DataFrame()))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
