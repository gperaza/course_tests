OK_FORMAT = True

test = {   'name': 'q2ci',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(missing_postal_code) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bus_missing.shape[0] == 194\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
