OK_FORMAT = True

test = {'name': 'q3civ', 'points': 1, 'suites': [{'cases': [{'code': ">>> 'year' in ins.columns\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
