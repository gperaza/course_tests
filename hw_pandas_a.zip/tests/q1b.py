OK_FORMAT = True

test = {   'name': 'q1b',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> len(top_names) == 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(top_addresses) == 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> top_names[-1] == 'STARBUCKS' or top_names[-1] == 'Proper Food'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> top_addresses[-1] == '103 Horne Ave'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
