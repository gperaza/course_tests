OK_FORMAT = True

test = {   'name': 'q2bi',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(valid_zips) == pd.Series\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(valid_zips.dtype == np.int64)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> valid_zips.values\n'
                                               'array([94102, 94103, 94104, 94105, 94107, 94108, 94109, 94110, 94111,\n'
                                               '       94112, 94114, 94115, 94116, 94117, 94118, 94119, 94120, 94121,\n'
                                               '       94122, 94123, 94124, 94125, 94126, 94127, 94128, 94129, 94130,\n'
                                               '       94131, 94132, 94133, 94134, 94137, 94139, 94140, 94141, 94142,\n'
                                               '       94143, 94144, 94145, 94146, 94147, 94151, 94158, 94159, 94160,\n'
                                               '       94161, 94163, 94164, 94172, 94177, 94188])',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
