OK_FORMAT = True

test = {'name': 'q4c', 'points': 1, 'suites': [{'cases': [{'code': '>>> bool(len(bins_arr) == 10)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
