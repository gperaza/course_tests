OK_FORMAT = True

test = {   'name': 'q2f',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> bool(bus_valid.shape[0] > 6000)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
