OK_FORMAT = True

test = {   'name': 'q1a',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> isinstance(is_bid_unique, (bool, np.bool))\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
