OK_FORMAT = True

test = {   'name': 'q4a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> len(bus_valid.columns) == 11 and 'first_char' in bus_valid.columns\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(bus_valid.shape == (6032, 11))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
