OK_FORMAT = True

test = {   'name': 'q4b',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> 5000 < bus_digits.shape[0] < 6000\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
