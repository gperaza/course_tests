OK_FORMAT = True

test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> party_result_popular_vote_pivot.index.name == 'Party'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> 'Result' in party_result_popular_vote_pivot.columns.names\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> int(party_result_popular_vote_pivot.isnull().sum().sum()) == 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> int(party_result_popular_vote_pivot.isnull().sum().sum()) == 0\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> int(party_result_popular_vote_pivot.loc['American', 'Popular vote']['loss'] if isinstance(party_result_popular_vote_pivot.columns, pd.MultiIndex) "
                                               "else party_result_popular_vote_pivot.loc['American']['loss']) == 158271\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> int(party_result_popular_vote_pivot.loc['American', 'Popular vote']['win'] if isinstance(party_result_popular_vote_pivot.columns, pd.MultiIndex) "
                                               "else party_result_popular_vote_pivot.loc['American']['win']) == 0\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> int(party_result_popular_vote_pivot.loc['Democratic', 'Popular vote']['loss'] if isinstance(party_result_popular_vote_pivot.columns, "
                                               "pd.MultiIndex) else party_result_popular_vote_pivot.loc['Democratic']['loss']) == 314190254\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> int(party_result_popular_vote_pivot.loc['Democratic', 'Popular vote']['win'] if isinstance(party_result_popular_vote_pivot.columns, pd.MultiIndex) "
                                               "else party_result_popular_vote_pivot.loc['Democratic']['win']) == 441751531\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
