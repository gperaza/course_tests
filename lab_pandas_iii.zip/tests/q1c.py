OK_FORMAT = True

test = {   'name': 'q1c',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> major_party_results_since_1988.shape == (41, 6)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(np.isclose(float(major_party_results_since_1988['%'].min()), 0.098088334))\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> major_party_results_since_1988['Candidate'].iloc[0] == 'Andre Marrou'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
