OK_FORMAT = True

test = {   'name': 'q1b',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> best_result.shape == (15, 5)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(np.isclose(float(best_result['Popular vote'].sum()), 135020916.0))\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> best_result.loc['Democratic', 'Candidate'] == 'Lyndon Johnson'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
