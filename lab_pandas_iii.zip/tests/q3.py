OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> presidential_candidates_and_name_popularity.shape == (147, 9)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> presidential_candidates_and_name_popularity[presidential_candidates_and_name_popularity['Candidate'] == 'Andrew Jackson'].iloc[0]['Name'] == "
                                               "'Andrew'\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> int(presidential_candidates_and_name_popularity[presidential_candidates_and_name_popularity['Candidate'] == 'William Lemke'].iloc[0]['Count']) == "
                                               '831\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
