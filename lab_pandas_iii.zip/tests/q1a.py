OK_FORMAT = True

test = {   'name': 'q1a',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(best_result_percentage_only) == 15\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(np.isclose(float(best_result_percentage_only['Independent'].sum()), 18.95629754))\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.isclose(float(best_result_percentage_only.iloc[0]), 61.34470329))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
