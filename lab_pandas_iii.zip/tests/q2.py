OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> elections_with_first_name.shape == (187, 7)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> elections_with_first_name[elections_with_first_name['Candidate'] == 'Andrew Jackson'].iloc[0]['First Name'] == 'Andrew'\nTrue",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> elections_with_first_name[elections_with_first_name['Candidate'] == 'Jo Jorgensen'].iloc[0]['First Name'] == 'Jo'\nTrue",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
