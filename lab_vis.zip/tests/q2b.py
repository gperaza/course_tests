OK_FORMAT = True

test = {   'name': 'q2b',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> bool(np.isclose(kde(gaussian_kernel, 1.0, 2.0, np.array([3.0, 4.0, 5.0, 7.0])), 0.075099))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.isclose(kde(gaussian_kernel, 2, 5, np.array([1.0, 3.0, 4.0, 5.0, 7.0, 100])), 0.107411))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(np.isclose(kde(gaussian_kernel, 100, 370, df['inc']), 0.000248205))\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
