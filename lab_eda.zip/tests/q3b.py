OK_FORMAT = True

test = {   'name': 'q3b',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> 'Lat' in calls.columns and 'Lon' in calls.columns\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> str(calls.loc[1137, 'Lat']) == '37.8801'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> str(calls.loc[689]['Lon']) == '-122.26857'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
