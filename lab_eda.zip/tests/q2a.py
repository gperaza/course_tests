OK_FORMAT = True

test = {   'name': 'q2a',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> set(calls['Day']) == {'Friday', 'Monday', 'Saturday', 'Sunday', 'Thursday', 'Tuesday', 'Wednesday'}\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> list(calls['Day'][:5]) == ['Wednesday', 'Thursday', 'Wednesday', 'Friday', 'Wednesday']\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
