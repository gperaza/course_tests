OK_FORMAT = True

test = {   'name': 'q3a',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> calls_lat_lon.shape == (4490, 2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(set(calls_lat_lon.columns) == {'Lat', 'Lon'})\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
