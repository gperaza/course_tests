OK_FORMAT = True

test = {   'name': 'q3c',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> invalid_block_loc.shape == (14, 15)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(invalid_block_loc['BLKADDR'].isna().sum() == len(invalid_block_loc))\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
