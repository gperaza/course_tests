OK_FORMAT = True

test = {   'name': 'q2b',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> isinstance(calls.loc[72, 'Hour'], (int, np.integer))\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(calls['Hour'][72] == 18)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
