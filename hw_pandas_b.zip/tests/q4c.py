OK_FORMAT = True

test = {   'name': 'q4c',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> all(reinspections_filtered.columns == ['bid', 'routine timestamp', 'routine score', 'name', 'day difference', 'recent reinspection?', 'score "
                                               "buckets'])\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> reinspections_filtered.equals(reinspections.groupby('score buckets').filter(lambda df: len(df) >= 125))\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
