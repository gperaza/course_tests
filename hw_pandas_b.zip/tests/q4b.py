OK_FORMAT = True

test = {   'name': 'q4b',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> reinspections.shape == (14077, 7)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> all(reinspections.columns == ['bid', 'routine timestamp', 'routine score', 'name', 'day difference', 'recent reinspection?', 'score buckets'])\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
