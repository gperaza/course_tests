OK_FORMAT = True

test = {   'name': 'q2c',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> worst_3_inspection_restaurants.shape == (15, 2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(worst_3_inspection_restaurants.index.names) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(worst_3_inspection_restaurants.iloc[0].iloc[0] == 'Chaat Corner')\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
