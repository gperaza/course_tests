OK_FORMAT = True

test = {   'name': 'q1a',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> bool(len(ins_score_by_type.columns) == 1)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(ins_score_by_type.columns[0] == 'max_score')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(set(ins_score_by_type.index) == set(ins['type'].unique()))\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
