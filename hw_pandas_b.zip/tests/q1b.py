OK_FORMAT = True

test = {   'name': 'q1b',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> bool(('New Ownership - Followup', 'Yes') in ins_missing_score_group.index)\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(ins_missing_score_group.columns[0] == 'Count')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(len(ins_missing_score_group) == 16)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
