OK_FORMAT = True

test = {   'name': 'q1c',
    'points': 3,
    'suites': [   {   'cases': [{'code': '>>> bool(type(ins_missing_score_pivot) == pd.DataFrame)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
