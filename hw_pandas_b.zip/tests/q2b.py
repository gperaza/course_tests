OK_FORMAT = True

test = {   'name': 'q2b',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> twenty_lowest_scoring.shape == (20, 2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(twenty_lowest_scoring.index.names) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> twenty_lowest_scoring.iloc[0].iloc[0] == 'Lollipot'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
