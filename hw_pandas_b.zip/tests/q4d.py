OK_FORMAT = True

test = {   'name': 'q4d',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> reinspection_proportions.shape == (6, 2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> reinspection_proportions.columns[0] == ('recent reinspection?', 'proportion')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> reinspection_proportions.columns[1] == ('recent reinspection?', 'count')\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
