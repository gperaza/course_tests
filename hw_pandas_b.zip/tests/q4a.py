OK_FORMAT = True

test = {   'name': 'q4a',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> reinspections.shape == (14077, 6)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> bool((reinspections.columns == ['bid', 'routine timestamp', 'routine score', 'name', 'day difference', 'recent reinspection?']).all())\nTrue",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
