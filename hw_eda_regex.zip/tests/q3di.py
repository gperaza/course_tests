OK_FORMAT = True

test = {   'name': 'q3di',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> top_positive.shape[0] == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> top_negative.shape[0] == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.isclose(top_negative.article_sentiment.max(), -0.9996978044509888))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
