OK_FORMAT = True

test = {   'name': 'q2aii',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> set(news_df_dates.columns) == {'Minute', 'Month', 'Year', 'lead_paragraph', 'pub_date', 'web_url'}\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
