OK_FORMAT = True

test = {   'name': 'q2c',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> re.findall(modified_pattern, \'"Mitochondria is the powerhouse of the cell."\') == [\'"Mitochondria is the powerhouse of the cell."\']\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> re.findall(modified_pattern, 'there is no quote in this sentence') == []\nTrue", 'hidden': False, 'locked': False},
                                   {   'code': '>>> re.findall(modified_pattern, \'Brandon said, "Recently, DATA C100 course staffs have hosted a social event with staffs from DATA C8."\') == '
                                               '[\'"Recently, DATA C100 course staffs have hosted a social event with staffs from DATA C8."\']\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> re.findall(modified_pattern, \'"R is great," a TA said, "but have you tried using Python?"\') == [\'"R is great," a TA said, "but have you tried '
                                               'using Python?"\']\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> re.findall(modified_pattern, \'"How are your classes?" the student asked. "Super challenging! But a lot of fun!" said their roommate.\') == '
                                               '[\'"How are your classes?"\', \'"Super challenging! But a lot of fun!"\']\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
