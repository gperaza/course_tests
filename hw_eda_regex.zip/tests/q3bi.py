OK_FORMAT = True

test = {   'name': 'q3bi',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> news_df_filtered.shape == (1135, 11)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
