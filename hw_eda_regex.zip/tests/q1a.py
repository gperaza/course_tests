OK_FORMAT = True

test = {   'name': 'q1a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> q1a.startswith(\'[{"web_url":"https:\\\\/\\\\/www.nytimes.com\\\\/2019\\\\/01\\\\/01\\\\/us\\\\/politics\\\\/elizabeth-warren-president.html"\')\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
