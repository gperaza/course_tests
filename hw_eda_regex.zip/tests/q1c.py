OK_FORMAT = True

test = {   'name': 'q1c',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> set(['web_url', 'pub_date', 'lead_paragraph']) == set(news_df.columns)\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> news_df.shape == (1885, 3)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> news_df.loc[50, 'web_url'] == 'https://www.nytimes.com/2019/07/30/arts/television/four-weddings-and-a-funeral-review-hulu.html'\nTrue",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> news_df.loc[203, 'pub_date'] == '2020-06-02T19:31:01+0000'\nTrue", 'hidden': False, 'locked': False},
                                   {   'code': ">>> news_df.loc[919, 'lead_paragraph'] == 'At the Chelsea Piers outdoor golf club, on a recent unseasonably warm Monday afternoon, 55 people were "
                                               'playing golf by 3:45, and a handful were sipping beers. At CutLoose hair salon, in Brooklyn, N.Y., the stylists now watch their clients take Zoom '
                                               'meetings from the salon chairs. And at Skyway Golf Course, in Jersey City, N.J., Steve Mills, a general manager, has noticed that weekday afternoons '
                                               "are jammed with a new group of golfers.'\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
