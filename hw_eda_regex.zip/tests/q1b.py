OK_FORMAT = True

test = {   'name': 'q1b',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> q1b.upper() in ['A', 'B', 'C', 'D']\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
