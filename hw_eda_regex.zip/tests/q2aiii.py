OK_FORMAT = True

test = {   'name': 'q2aiii',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> 'Quarter' in news_df_dates.columns\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> news_df_dates.loc[938, 'Quarter'] == '2023Q1'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> news_df_dates.loc[201, 'Quarter'] == '2020Q2'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> news_df_dates.loc[734, 'Quarter'] == '2022Q3'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> news_df_dates.loc[594, 'Quarter'] == '2021Q4'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
