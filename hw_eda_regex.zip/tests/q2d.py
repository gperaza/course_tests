OK_FORMAT = True

test = {   'name': 'q2d',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> news_df_dates.shape[0] == 1885\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> set(news_df_dates.columns) == {'GPT Model', 'Minute', 'Month', 'New Year', 'Quarter', 'Wordle', 'Year', 'Zoom', 'lead_paragraph', 'pub_date', "
                                               "'web_url'}\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> len(news_df_dates[news_df_dates['GPT Model'] > 0]) == 173\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> len(news_df_dates[news_df_dates['Wordle'] > 0]) == 724\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> len(news_df_dates[news_df_dates['Zoom'] > 0]) == 463\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> len(news_df_dates[news_df_dates['New Year'] > 0]) == 501\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
