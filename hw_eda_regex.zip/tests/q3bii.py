OK_FORMAT = True

test = {   'name': 'q3bii',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> 'article_sentiment' in news_df_sentiment.columns\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> news_df_sentiment.shape == (1054, 12)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> set(news_df_sentiment.columns) == {'GPT Model', 'Minute', 'Month', 'New Year', 'Quarter', 'Wordle', 'Year', 'Zoom', 'lead_paragraph', 'pub_date', "
                                               "'article_sentiment', 'web_url'}\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> bool(news_df_sentiment['article_sentiment'].iloc[1] <= 1 and news_df_sentiment['article_sentiment'].iloc[1] >= -1)\nTrue",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
