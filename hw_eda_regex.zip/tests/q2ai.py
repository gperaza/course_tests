OK_FORMAT = True

test = {   'name': 'q2ai',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> {'Month', 'Year', 'Minute'} == set(dates.columns).intersection({'Month', 'Year', 'Minute'})\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> dates['Year'].dtype == int\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> dates['Month'].dtype == int\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> dates['Minute'].dtype == int\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
