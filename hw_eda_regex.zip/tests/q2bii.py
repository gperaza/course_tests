OK_FORMAT = True

test = {   'name': 'q2bii',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> q2bii.upper() in ['A', 'B', 'C']\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
