OK_FORMAT = True

test = {   'name': 'q2bi',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> q2bi.upper() in ['A', 'B', 'C']\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
