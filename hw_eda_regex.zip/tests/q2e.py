OK_FORMAT = True

test = {   'name': 'q2e',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> topic_mentions.shape == (24, 4)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> set(topic_mentions.columns) == {'Zoom', 'New Year', 'GPT Model', 'Wordle'}\nTrue", 'hidden': False, 'locked': False},
                                   {   'code': ">>> set(topic_mentions.index) == {'2019Q1', '2019Q2', '2019Q3', '2019Q4', '2020Q1', '2020Q2', '2020Q3', '2020Q4', '2021Q1', '2021Q2', '2021Q3', "
                                               "'2021Q4', '2022Q1', '2022Q2', '2022Q3', '2022Q4', '2023Q1', '2023Q2', '2023Q3', '2023Q4', '2024Q1', '2024Q2', '2024Q3', '2024Q4'}\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
