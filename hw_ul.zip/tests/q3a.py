OK_FORMAT = True

test = {   'name': 'q3a',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(k_opt, int)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(km_opt, kmedoids.KMedoids)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> km_opt.get_params()['method'] == 'fasterpam'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> km_opt.get_params()['metric'] == 'precomputed'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
