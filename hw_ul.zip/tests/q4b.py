OK_FORMAT = True

test = {   'name': 'q4b',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> d.shape == (1653,)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.round(d.max(), 2) == 10.65)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.round(d.min(), 2) == 0.09)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
