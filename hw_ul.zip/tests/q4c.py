OK_FORMAT = True

test = {   'name': 'q4c',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> Z.shape == (57, 4)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(Z.max() == 113)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(Z.min() == 0.0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
