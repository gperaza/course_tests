OK_FORMAT = True

test = {   'name': 'q2c',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> isinstance(table, pd.Series)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
