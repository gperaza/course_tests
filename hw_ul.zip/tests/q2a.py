OK_FORMAT = True

test = {   'name': 'q2a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> inputs.shape == (3137, 6)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.all(np.isclose(inputs.mean(axis=0), 0)))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.all(np.isclose(inputs.std(axis=0), 1)))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
