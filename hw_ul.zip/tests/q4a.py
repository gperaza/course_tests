OK_FORMAT = True

test = {   'name': 'q4a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> rho.shape == (58, 58)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.array(rho).max() == 1.0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.round(np.array(rho).min(), 2) == -0.84)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
