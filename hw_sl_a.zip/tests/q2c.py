OK_FORMAT = True

test = {   'name': 'q2c',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(est, statsmodels.discrete.discrete_model.BinaryResultsWrapper)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(est.params) == 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(est.params.const < 10)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(est.params.balance < 1) & bool(est.params.balance > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(est.params.income < 0.001) & bool(est.params.income > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(est.params.student_bin > -1) & bool(est.params.student_bin < 1)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
