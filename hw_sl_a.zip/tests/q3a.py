OK_FORMAT = True

test = {   'name': 'q3a',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> len(X_test) == 2500\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(y_test) == 2500\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(X_train) == 7500\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(y_train) == 7500\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(model, linear_model.LogisticRegression)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(model.intercept_) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(model.coef_[0]) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(model.intercept_[0] < -10)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(model.coef_[0][0] < 1) & bool(model.coef_[0][0] > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> cm.shape == (2, 2)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
