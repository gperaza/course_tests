OK_FORMAT = True

test = {   'name': 'q4d',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> X_test_scaled.shape == (1000, 85)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> X_train_scaled.shape == (4822, 85)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.all(np.isclose(X_train_scaled.mean(axis=0), 0)))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(np.all(np.isclose(X_train_scaled.std(axis=0), 1)))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> not np.all(np.isclose(X_test_scaled.mean(axis=0), 0))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> not np.all(np.isclose(X_test_scaled.std(axis=0), 1))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(model, KNeighborsClassifier)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
