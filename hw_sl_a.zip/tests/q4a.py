OK_FORMAT = True

test = {   'name': 'q4a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(corr, pd.Series)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(corr.index) == 85\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> set(corr.index) == set(caravan.drop(columns='Purchase').columns)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
