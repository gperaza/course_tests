OK_FORMAT = True

test = {   'name': 'q4f',
    'points': 3,
    'suites': [   {   'cases': [{'code': '>>> isinstance(k_opt, int)\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> 0 < k_opt < 11\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
