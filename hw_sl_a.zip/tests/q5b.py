OK_FORMAT = True

test = {   'name': 'q5b',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> X_train.shape == (184, 2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> X_test.shape == (79, 2)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> y_test.shape == (79,)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> y_train.shape == (184,)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> isinstance(model, DecisionTreeRegressor)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> model.get_params()['random_state'] == 0\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> model.get_params()['max_leaf_nodes'] == 3\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> mse_score < 170000\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
