OK_FORMAT = True

test = {   'name': 'q5d',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> X.shape == (263, 19)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> y.shape == (263,)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> bool(np.all(np.round(X.mean(axis=0), 2) == [403.64, 107.83, 11.62, 54.75, 51.49, 41.11, 7.31, 2657.54, 722.19, 69.24, 361.22, 330.42, 260.27, '
                                               '290.71, 118.76, 8.59, 0.47, 0.51, 0.46]))\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> isinstance(model, RandomForestRegressor)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> model.get_params()['random_state'] == 0\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(mse_score < 100000)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
