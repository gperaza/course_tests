OK_FORMAT = True

test = {   'name': 'q2a',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(est, statsmodels.discrete.discrete_model.BinaryResultsWrapper)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(est.params) == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(est.params.const < 10)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(est.params.balance < 1)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(est.params.balance > 0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
