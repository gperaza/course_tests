OK_FORMAT = True

test = {   'name': 'q5a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> 'time_category' in bike.columns\nTrue", 'hidden': False, 'locked': False},
                                   {   'code': ">>> expected_categories = {'Midnight', 'Morning', 'Lunch Time', 'Afternoon', 'Evening', 'Night'}\n"
                                               ">>> set(bike['time_category'].unique()) == expected_categories\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> len(bike) == len(bike.drop(columns=['time_category']))\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
