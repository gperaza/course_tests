OK_FORMAT = True

test = {   'name': 'q6a',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> int(bike['prop_casual'].sum()) == 2991\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
