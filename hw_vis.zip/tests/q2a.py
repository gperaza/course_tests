OK_FORMAT = True

test = {   'name': 'q2a',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(bike, pd.DataFrame)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bike['holiday'].dtype == np.dtype('O')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> list(bike['holiday'].iloc[370:375]) == ['no', 'no', 'yes', 'yes', 'yes']\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> bike['weekday'].dtype == np.dtype('O')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> bike['workingday'].dtype == np.dtype('O')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> bike['weathersit'].dtype == np.dtype('O')\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
