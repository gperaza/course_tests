OK_FORMAT = True

test = {   'name': 'q2b',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> bool(np.all(daily_counts.sort_index().index[0:5] == ['2011-01-01', '2011-01-02', '2011-01-03', '2011-01-04', '2011-01-05']))\nTrue",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> bool(type(daily_counts) == pd.DataFrame)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> bool(np.isclose(np.round(daily_counts['casual'].var()), 471450))\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
